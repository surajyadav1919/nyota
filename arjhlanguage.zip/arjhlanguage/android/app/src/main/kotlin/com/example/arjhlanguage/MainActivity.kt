package com.example.arjhlanguage

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
