// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// class WeightPicker extends StatefulWidget {
//   const WeightPicker({Key? key}) : super(key: key);
//
//   @override
//   State<WeightPicker> createState() => _WeightPickerState();
// }
//
// var _selectedWeight = 150;
// var _selectedWeightDecimals = 0;
// var _selectedUnits = 'lbs';
// var units = ['kgs', 'lbs'];
// var lbs = [];
// var kgs = [];
// // var _selectedUnits = ValueNotifier('lbs');
//
// @override
// void initState() {
//   for (int j = 22; j <= 227; j++) {
//     kgs.add(j);
//     lbs.add(j * 2.20462);
//   }
// }
//
// class _WeightPickerState extends State<WeightPicker> {
//
//   var _formKey;
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Container(
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             const SizedBox(height: 15),
//             const Text(
//               'WEIGHT',
//               // style: TextConstants.feildHeadText,
//             ),
//             const SizedBox(
//               height: 2,
//             ),
//             Container(
//               height: 51,
//               width: double.infinity,
//               padding: const EdgeInsets.only(left: 10, right: 10),
//               decoration: BoxDecoration(
//                 borderRadius: const BorderRadius.all(Radius.circular(40)),
//                 border: Border.all(
//                   color: Colors.grey,
//                   width: 1,
//                 ),
//               ),
//               child: Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                 children: [
//                   CupertinoButton(
//                     onPressed: () {
//                       showModalBottomSheet(
//                         context: context,
//                         builder: (BuildContext context) {
//                           return SizedBox(
//                             height: 200,
//                             child: Row(
//                               crossAxisAlignment: CrossAxisAlignment.start,
//                               children: [
//                                 Expanded(
//                                   child: CupertinoPicker(
//                                     itemExtent: 32,
//                                     onSelectedItemChanged: (int index) {
//                                       if (_formKey.currentState!.validate()) {
//                                         const Text(
//                                           "Please select Weight",
//                                           style: TextStyle(
//                                             color: Colors.red,
//                                             fontSize: 16,
//                                           ),
//                                         );
//                                       }
//                                       setState(
//                                             () {
//                                           _selectedWeight = kgs[index];
//                                         },
//                                       );
//                                     },
//                                     children: List<Widget>.generate(
//                                       kgs.length,
//                                           (int index) {
//                                         return Center(
//                                           child: Text(kgs[index].toString()),
//                                         );
//                                       },
//                                     ),
//                                   ),
//                                 ),
//                                 Expanded(
//                                   child: CupertinoPicker(
//                                     itemExtent: 32,
//                                     onSelectedItemChanged: (int index) {
//                                       if (_formKey.currentState!.validate()) {
//                                         const Text(
//                                           "Please select Units",
//                                           style: TextStyle(
//                                             color: Colors.red,
//                                             fontSize: 16,
//                                           ),
//                                         );
//                                       }
//                                       setState(
//                                             () {
//                                           _selectedUnits = units[index] as ValueNotifier<String>;
//                                         },
//                                       );
//                                     },
//                                     children: List<Widget>.generate(
//                                       units.length,
//                                           (int index) {
//                                         return Center(
//                                           child: Text(units[index]),
//                                         );
//                                       },
//                                     ),
//                                   ),
//                                 ),
//                               ],
//                             ),
//                           );
//                         },
//                       );
//                     },
//                     child: Text(
//                       '$_selectedWeight.$_selectedWeightDecimals  $_selectedUnits',
//                       style: const TextStyle(
//                         height: 1,
//                         color: Colors.black,
//                         fontSize: 16,
//                       ),
//                     ),
//                   ),
//                   // SvgPicture.asset(
//                   //   'assets/icons/dropdown.svg',
//                   // ),
//                 ],
//               ),
//             ),
//             Expanded(
//               child: ValueListenableBuilder<String>(
//                   valueListenable: _selectedUnits,
//                   builder: (context, selectedUnits, _) {
//                     return CupertinoPicker(
//                       itemExtent: 32,
//                       onSelectedItemChanged: (int index) {
//                         if (_formKey.currentState!.validate()) {
//                           const Text("Please select Weight",
//                             style: TextStyle(
//                               color: Colors.red,
//                               fontSize: 16,
//                             ),
//                           );
//                         }
//                         setState(
//                               () {
//                             if (selectedUnits == 'Kgs') {
//                               _selectedWeight = kgs[index];
//                             } else {
//                               _selectedWeight = lbs[index];
//                             }
//                           },
//                         );
//                       },
//                       children: List<Widget>.generate(
//                         kgs.length,
//                             (int index) {
//                           return Center(
//                             child: Text(
//                                 '${selectedUnits == 'kgs' ? kgs[index] : lbs[index]}'),
//                           );
//                         },
//                       ),
//                     );
//                   }),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
