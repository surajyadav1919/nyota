import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class DatePicker extends StatefulWidget {
  const DatePicker({super.key});

  @override
  State<DatePicker> createState() => _DatePickerState();
}

class _DatePickerState extends State<DatePicker> {
  final dateController = TextEditingController();

  @override
  void dispose() {
    // Clean up the controller when the widget is removed
    dateController.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      height: 50,
      width: 200,
      decoration: BoxDecoration(
        color: Color(0xffD91542),
        borderRadius: BorderRadius.circular(25),
      ),
      child: TextFormField(
        style: TextStyle(color: Colors.white,fontSize: 20,),
        readOnly: true,
        controller: dateController,
        decoration: const InputDecoration(
            suffixIcon: Icon(Icons.calendar_month_rounded,color: Colors.white,),
            border: InputBorder.none,
            contentPadding: EdgeInsets.symmetric(horizontal: 20,vertical: 15),
            hintStyle: TextStyle(color: Colors.white),
            hintText: 'Select DOB Date'),

        onTap: () async {
          var date = await showDatePicker(
              context: context,
              initialDate: DateTime(2010,),
              firstDate: DateTime(2000),
              lastDate: DateTime(2100));
          if (date != null) {
            dateController.text = DateFormat('dd/MM/yyyy').format(date);
          }
        },
      ),
    );
  }
}
