import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
class StyleConstant{
 static final TextStyle script_text=GoogleFonts.dancingScript(color: Color(0xffE8EFFD),);
 static final TextStyle title_text=GoogleFonts.inter(color: Color(0xffE8EFFD),fontWeight: FontWeight.bold, fontSize: 25,);

}