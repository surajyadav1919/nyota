import 'package:flutter/material.dart';

class ColorConstants{
  static const Color backgroundColor=Color(0xff1AA7DD);
  static const Color button_color=Color(0xffD91542);
  static const Color home=Color(0xffE8EFFD);
  static const Color dropdowncolor=Color(0xff7dd2e8);
}