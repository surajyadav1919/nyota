class AppLocalizations {
  static const String agetitle = "agetitle";
  static const String age = "age";
  static const String gender = "gender";
  static const String weight = "weight";
  static const String height = "height";
  static const String wakeuptime = "wakeuptime";
  static const String bedtime = "bedtime";

}
