import 'package:flutter/material.dart';
class CustomButtom extends StatelessWidget {
  const CustomButtom({Key? key, required this.height, required this.width, required this.text, required this.ontap,}) : super(key: key);
final double height;
final double width;
final String text;
final VoidCallback ontap;
// final IconData? sufixicon;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap:ontap,
      child: Container(
        height: height,
        width: width,
        decoration: BoxDecoration(
          color: Color(0xffD91542),
          borderRadius: BorderRadius.circular(25),
        ),
        child: Row(mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
             text,
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
            // Icon(sufixicon,size: 20,color: Colors.white,),
          ],
        ),
      ),
    );
  }
}
