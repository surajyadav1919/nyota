import 'package:arjhlanguage/constant/app_localizations.dart';
import 'package:arjhlanguage/constant/color_costants.dart';
import 'package:arjhlanguage/constant/datepicker.dart';
import 'package:arjhlanguage/custom/custombutton.dart';
import 'package:arjhlanguage/presentation/modules/user_input/select_gender.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
class SelectAge extends StatefulWidget {
  const SelectAge({Key? key}) : super(key: key);

  @override
  State<SelectAge> createState() => _SelectAgeState();
}

class _SelectAgeState extends State<SelectAge> {
  bool toggleswitch = false;

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: ColorConstants.backgroundColor,
        actions: [
          IconButton(
              onPressed: () {
                setState(() {
                  toggleswitch = !toggleswitch;
                });
              },
              icon: toggleswitch
                  ? Icon(
                Icons.volume_up_outlined,
                color: Colors.green,
              )
                  : Icon(
                Icons.volume_off_outlined,
                color: Colors.red,
              )),
        ],
      ),
      backgroundColor: ColorConstants.backgroundColor,
      body: Container(
        height: double.infinity,
        width: double.infinity,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Stack(
            children: [
              Column(
                children: [
                  SizedBox(height: size.height*0.15,),
                  Text(
                    textAlign: TextAlign.center,
                    AppLocalizations.agetitle.tr,
                    style: TextStyle(
                      color: Color(0xffE8EFFD),
                      fontSize: 30,
                    ),
                  ),
                  SizedBox(height: 30,),
                  Text(
                    textAlign: TextAlign.center,
                    AppLocalizations.age.tr,
                    style: TextStyle(
                      color: Color(0xffE8EFFD),
                      fontSize: 30,
                    ),
                  ),
                  SizedBox(height: 30,),
                  DatePicker(),
                ],
              ),
              Positioned(
                right: 15,
                bottom: 30,
                child: CustomButtom(height: 40, width: 100, text: 'Next',
                    ontap: (){
                  Get.to(SelectGender());
                    }),
              )
            ],
          ),
        ),
      ),
    );
  }
}
