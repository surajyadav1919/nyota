import 'package:arjhlanguage/constant/app_localizations.dart';
import 'package:arjhlanguage/constant/color_costants.dart';
import 'package:arjhlanguage/custom/custombutton.dart';
import 'package:arjhlanguage/presentation/modules/user_input/your_weight.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
class SelectGender extends StatefulWidget {
  const SelectGender({Key? key}) : super(key: key);

  @override
  State<SelectGender> createState() => _SelectGenderState();
}

class _SelectGenderState extends State<SelectGender> {
  bool toggleswitch = false;
  String selectedValue = "";

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: ColorConstants.backgroundColor,
        actions: [
          IconButton(
              onPressed: () {
                setState(() {
                  toggleswitch = !toggleswitch;
                });
              },
              icon: toggleswitch
                  ? Icon(
                Icons.volume_up_outlined,
                color: Colors.white,
              )
                  : Icon(
                Icons.volume_off_outlined,
                color: Colors.red,
              )),
        ],
      ),
      backgroundColor: ColorConstants.backgroundColor,
      body: Container(
        height: double.infinity,
        width: double.infinity,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Stack(
            children: [
              Column(
                children: [
                  SizedBox(height: size.height*0.15,),
                  Text(
                    textAlign: TextAlign.center,
                    AppLocalizations.gender.tr,
                    style: TextStyle(
                      color: Color(0xffE8EFFD),
                      fontSize: 30,
                    ),
                  ),
                  SizedBox(height: 30,),
                  GestureDetector(
                    onTap:(){
                      setState(() {
                        selectedValue='He';
                      });
                    },
                    child: Container(
                      height: 45,
                      width: 120,
                      decoration: BoxDecoration(
                        color: Color(0xffD91542),
                        border: selectedValue=='He'
                            ?Border.all(width: 2,color: Colors.white)
                        :Border.all(width: 2,color: Colors.grey),
                        borderRadius: BorderRadius.circular(25),
                      ),
                      child: Row(mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'He',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          // Icon(sufixicon,size: 20,color: Colors.white,),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(height: 30,),
                  GestureDetector(
                    onTap:(){
                      setState(() {
                        selectedValue='She';
                      });
                    },
                    child: Container(
                      height: 45,
                      width: 120,
                      decoration: BoxDecoration(
                        color: Color(0xffD91542),
                        border: selectedValue=='She'
                            ?Border.all(width: 2,color: Colors.white)
                            :Border.all(width: 2,color: Colors.grey),
                        borderRadius: BorderRadius.circular(25),
                      ),
                      child: Row(mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'She',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          // Icon(sufixicon,size: 20,color: Colors.white,),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              Positioned(
                right: 15,
                bottom: 30,
                child: CustomButtom(height: 40, width: 100, text: 'Next',
                    ontap: (){
                  Get.to(YourWeight());
                    }),
              )
            ],
          ),
        ),
      ),
    );
  }
}
