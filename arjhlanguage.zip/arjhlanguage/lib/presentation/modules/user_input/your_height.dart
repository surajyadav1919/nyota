import 'package:arjhlanguage/constant/app_localizations.dart';
import 'package:arjhlanguage/constant/color_costants.dart';
import 'package:arjhlanguage/constant/style_constant.dart';
import 'package:arjhlanguage/custom/custombutton.dart';
import 'package:arjhlanguage/presentation/modules/user_input/wake_up_time.dart';
import 'package:arjhlanguage/presentation/widgets/dropdown_widgets.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:numberpicker/numberpicker.dart';

class YourHeight extends StatefulWidget {
  const YourHeight({Key? key}) : super(key: key);

  @override
  State<YourHeight> createState() => _YourHeightState();
}

class _YourHeightState extends State<YourHeight> {
  bool toggleswitch = false;
  int _currentIntValue = 4;
  int _currentdecimalValue = 0;

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: ColorConstants.backgroundColor,
        actions: [
          IconButton(
              onPressed: () {
                setState(() {
                  toggleswitch = !toggleswitch;
                });
              },
              icon: toggleswitch
                  ? Icon(
                      Icons.volume_up_outlined,
                      color: Colors.white,
                    )
                  : Icon(
                      Icons.volume_off_outlined,
                      color: Colors.red,
                    )),
        ],
      ),
      backgroundColor: ColorConstants.backgroundColor,
      body: Container(
        height: double.infinity,
        width: double.infinity,
        child: Stack(
          alignment: Alignment.center,
          children: [
            Column(
              children: [
                SizedBox(
                  height: size.height * 0.15,
                ),
                Text(
                  textAlign: TextAlign.center,
                  AppLocalizations.height.tr,
                  style: TextStyle(
                    color: Color(0xffE8EFFD),
                    fontSize: 30,
                  ),
                ),
                SizedBox(
                  height: 30,
                ),
                Stack(
                  children: [
                    Container(
                      width: size.width * 0.8,
                      decoration: BoxDecoration(
                        color: ColorConstants.button_color,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          NumberPicker(
                            textStyle: TextStyle(color: Colors.white70),
                            selectedTextStyle:
                                TextStyle(color: Colors.white, fontSize: 25),
                            value: _currentIntValue,
                            minValue: 3,
                            maxValue: 7,
                            step: 1,
                            haptics: true,
                            onChanged: (value) =>
                                setState(() => _currentIntValue = value),
                            decoration: BoxDecoration(
                                border: Border(
                                    top: BorderSide(
                                        color: Colors.white70, width: 1),
                                    bottom: BorderSide(
                                      color: Colors.white70,
                                      width: 1,
                                    ))),
                          ),
                          NumberPicker(
                            textStyle: TextStyle(color: Colors.white70),
                            selectedTextStyle:
                                TextStyle(color: Colors.white, fontSize: 25),
                            value: _currentdecimalValue,
                            minValue: 0,
                            maxValue: 11,
                            step: 1,
                            haptics: true,
                            onChanged: (value) =>
                                setState(() => _currentdecimalValue = value),
                            decoration: BoxDecoration(
                                border: Border(
                                    top: BorderSide(
                                        color: Colors.white70, width: 1),
                                    bottom: BorderSide(
                                      color: Colors.white70,
                                      width: 1,
                                    ))),
                          ),
                        ],
                      ),
                    ),
                    // Positioned(
                    //   right: size.width*0.03,
                    //   top: size.height*0.065,
                    //   child: DropDown(hint: 'feet/cm', items: ['feet','cm'],),),
                  ],
                ),
                SizedBox(
                  height: 20,
                ),
                Text(
                  '$_currentIntValue' + "'" + ' $_currentdecimalValue' + '"',
                  style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
                ),
              ],
            ),
            Positioned(
              right: 15,
              bottom: 30,
              child: CustomButtom(
                  height: 40,
                  width: 100,
                  text: 'Next',
                  ontap: () {
                    Get.to(WakeUpTime());
                  }),
            ),
          ],
        ),
      ),
    );
  }
}
