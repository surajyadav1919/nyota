import 'package:arjhlanguage/constant/color_costants.dart';
import 'package:arjhlanguage/custom/custombutton.dart';
import 'package:arjhlanguage/presentation/modules/home/navbar/navbar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../constant/style_constant.dart';

class MiraSuggestion extends StatefulWidget {
  const MiraSuggestion({Key? key}) : super(key: key);

  @override
  State<MiraSuggestion> createState() => _MiraSuggestionState();
}

class _MiraSuggestionState extends State<MiraSuggestion> {
  bool toggleswitch = false;

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: ColorConstants.backgroundColor,
        actions: [
          IconButton(
              onPressed: () {
                setState(() {
                  toggleswitch = !toggleswitch;
                });
              },
              icon: toggleswitch
                  ? Icon(
                      Icons.volume_up_outlined,
                      color: Colors.white,
                    )
                  : Icon(
                      Icons.volume_off_outlined,
                      color: Colors.red,
                    )),
        ],
      ),
      backgroundColor: ColorConstants.backgroundColor,
      body: Container(
        height: double.infinity,
        width: double.infinity,
        child: Stack(
          alignment: Alignment.center,
          children: [
            Column(
              children: [
                SizedBox(
                  height: size.height * 0.03,
                ),
                Text(
                  textAlign: TextAlign.center,
                  'Mira Suggestion',
                  style: StyleConstant.title_text,
                ),
                SizedBox(
                  height: 30,
                ),
                Text(
                  textAlign: TextAlign.center,
                  'Your Daily Water intake',
                  style: TextStyle(
                    color: Color(0xffE8EFFD),
                    fontSize: 20,
                  ),
                ),
                SizedBox(
                  height: 30,
                ),
                Container(
                    alignment: Alignment.center,
                    height: size.height * 0.1,
                    width: size.width * 0.6,
                    decoration: BoxDecoration(
                      color: ColorConstants.button_color,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      '2140 ml',
                      style: TextStyle(color: Colors.white, fontSize: 25),
                    )),
                SizedBox(
                  height: 20,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 30),
                  child: Image.asset(
                    'assets/images/glass.png',
                    height: 300,
                  ),
                ),
                Text(
                  '10 times a day',
                  style: TextStyle(color: Colors.white),
                ),
                Text(
                  '214ml each time',
                  style: StyleConstant.title_text.copyWith(fontSize: 15),
                ),
              ],
            ),
            Positioned(
              right: 15,
              bottom: 30,
              child: CustomButtom(
                  height: 40, width: 100, text: 'Next', ontap: () {
                    Get.to(Navbar());
              }),
            ),
            Positioned(
              top: size.height*0.31,
                right: 45,
                child: Text(
              '10X',
              style: StyleConstant.script_text.copyWith(
                color: Colors.black,
                  fontSize: 50,
                shadows: <Shadow>[
                  Shadow(
                    offset: Offset(2.0, 2.0),
                    blurRadius: 3.0,
                    color: Colors.white70,
                  ),
                ],
              ),
            )),
          ],
        ),
      ),
    );
  }
}
