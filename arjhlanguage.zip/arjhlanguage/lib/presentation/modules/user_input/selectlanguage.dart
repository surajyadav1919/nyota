import 'package:arjhlanguage/constant/color_costants.dart';
import 'package:arjhlanguage/constant/style_constant.dart';
import 'package:arjhlanguage/custom/custombutton.dart';
import 'package:arjhlanguage/presentation/modules/user_input/select_age.dart';
import 'package:arjhlanguage/service/localization_controler.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

class SelectLanguage extends StatefulWidget {
  const SelectLanguage({Key? key}) : super(key: key);

  @override
  State<SelectLanguage> createState() => _SelectLanguageState();
}

class _SelectLanguageState extends State<SelectLanguage> {
  LocalizationController localizationController = Get.find();
  bool toggleswitch = false;
int index=0;
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: ColorConstants.backgroundColor,
        actions: [
          IconButton(
              onPressed: () {
                setState(() {
                  toggleswitch = !toggleswitch;
                });
              },
              icon: toggleswitch
                  ? Icon(
                Icons.volume_up_outlined,
                color: Colors.green,
              )
                  : Icon(
                Icons.volume_off_outlined,
                color: Colors.red,
              )),
        ],
      ),
      backgroundColor: ColorConstants.backgroundColor,
      body: Container(
        height: double.infinity,
        width: double.infinity,
        child: Column(
          children: [
            SizedBox(height: size.height*0.15,),
            Text(
              textAlign: TextAlign.center,
              'Please Select Your Language',
              style: StyleConstant.title_text.copyWith(
                fontSize: 30
              ),
            ),
            Text(
              textAlign: TextAlign.center,
              'कृपया अपनी भाषा चुनिए',
              style: StyleConstant.title_text.copyWith(
                fontSize: 30
              ),
            ),
            SizedBox(height: 30,),
            CustomButtom(
              ontap: ()async{
                await localizationController
                    .setLanguage(LocalizationController.appLanguages[0])
                    .then((value) {
                  setState(() {
                    index = 0;
                  });
                  // Navigator.push(context, MaterialPageRoute(builder: (context)=>English()));
                  Get.to(SelectAge());
                });
              },
              height: 50,
              width: size.width*0.35,
              text: 'English',
            ),
            SizedBox(height: 15,),
            CustomButtom(
              ontap: ()async{
                await localizationController
                    .setLanguage(LocalizationController.appLanguages[1])
                    .then((value) {
                  setState(() {
                    index = 1;
                  });
                  // Navigator.push(context, MaterialPageRoute(builder: (context)=>English()));
                  Get.to(SelectAge());
                });
              },
              height: 50,
              width: size.width*0.35,
              text: 'Hindi',
            ),

          ],
        ),
      ),
    );
  }
}
