import 'package:arjhlanguage/constant/app_localizations.dart';
import 'package:arjhlanguage/constant/color_costants.dart';
import 'package:arjhlanguage/custom/custombutton.dart';
import 'package:arjhlanguage/presentation/modules/user_input/mira_suggestion.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_time_picker_spinner/flutter_time_picker_spinner.dart';
import 'package:get/get.dart';

class SleepTime extends StatefulWidget {
  const SleepTime({Key? key}) : super(key: key);

  @override
  State<SleepTime> createState() => _SleepTimeState();
}

class _SleepTimeState extends State<SleepTime> {
  bool toggleswitch = false;
  int _currentIntValue = 5;
  DateTime _dateTime = DateTime.now();

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: ColorConstants.backgroundColor,
        actions: [
          IconButton(
              onPressed: () {
                setState(() {
                  toggleswitch = !toggleswitch;
                });
              },
              icon: toggleswitch
                  ? Icon(
                Icons.volume_up_outlined,
                color: Colors.white,
              )
                  : Icon(
                Icons.volume_off_outlined,
                color: Colors.red,
              )),
        ],
      ),
      backgroundColor: ColorConstants.backgroundColor,
      body: Container(
        height: double.infinity,
        width: double.infinity,
        child: Stack(
          alignment: Alignment.center,
          children: [
            Column(
              children: [
                SizedBox(height: size.height*0.15,),
                Text(
                  textAlign: TextAlign.center,
                  AppLocalizations.bedtime.tr,
                  style: TextStyle(
                    color: Color(0xffE8EFFD),
                    fontSize: 30,
                  ),
                ),
                SizedBox(height: 30,),
                Stack(
                  children: [
                    Container(
                      height: size.height*0.22,
                      width: size.width*0.8,
                      decoration: BoxDecoration(
                        color: ColorConstants.button_color,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child:  Column(
                        children: [
                          SizedBox(height: 50,),
                          Divider(thickness: 1,color: Colors.white70,),
                          SizedBox(height: 45,),
                          Divider(thickness: 1,color: Colors.white70,)

                        ],
                      ),
                    ),
                    Positioned(
                      top: 0,
                      left: 70,

                      child: hourMinute15Interval(),),
                  ],
                ),
                SizedBox(height: 20,),
                Text(
                  _dateTime.hour.toString().padLeft(2, '0') +
                      ':' +
                      _dateTime.minute.toString().padLeft(2, '0'),
                  // ':' +
                  // _dateTime.second.toString().padLeft(2, '0'),
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
              ],
            ),

            Positioned(
              right: 15,
              bottom: 30,
              child: CustomButtom(height: 40, width: 100, text: 'Next',
                  ontap: (){
                Get.to(MiraSuggestion());
                  }),
            ),

          ],
        ),
      ),
    );
  }
  Widget hourMinute15Interval() {
    return TimePickerSpinner(
      normalTextStyle: TextStyle(color: Colors.white54,fontSize: 15),
      highlightedTextStyle: TextStyle(color: Colors.white,fontSize: 25,),
      is24HourMode: true,
      spacing: 45,
      minutesInterval: 1,
      onTimeChange: (time) {
        setState(() {
          _dateTime = time;
        });
      },
    );
  }
}


