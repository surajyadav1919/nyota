import 'dart:async';
import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:arjhlanguage/constant/color_costants.dart';
import 'package:arjhlanguage/constant/style_constant.dart';
import 'package:arjhlanguage/presentation/modules/user_input/selectlanguage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    // Start the timer that will navigate to the main screen after 5 seconds
    Timer(Duration(seconds: 7), () {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (context) => SelectLanguage()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: ColorConstants.backgroundColor,
      body: Container(
        height: double.infinity,
        width: double.infinity,
        child: Stack(
          alignment: Alignment.center,
          children: [
            animatedtext(),
            Positioned(
              bottom: 30,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('Proudly Made in India',
                    style: StyleConstant.title_text),
                  Icon(CupertinoIcons.heart_fill,color: Colors.red,),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}

Widget animatedtext(){
  return DefaultTextStyle(
    textAlign: TextAlign.center,
    style: StyleConstant.script_text.copyWith(
      fontSize: 50
    ),
    child: AnimatedTextKit(
      totalRepeatCount: 1,
      pause: Duration(milliseconds: 100),
      animatedTexts: [
        TyperAnimatedText(
            speed : Duration(milliseconds: 250),
          "Hi!\nI'm Mira",),
        TyperAnimatedText(
            speed : Duration(milliseconds: 250),
            "नमस्ते!\nमैं मीरा हूँ।"),
      ],
    ),
  );
}
