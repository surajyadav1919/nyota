import 'package:flutter/material.dart';
class UnitDialoge extends StatefulWidget {
  const UnitDialoge({Key? key}) : super(key: key);

  @override
  State<UnitDialoge> createState() => _UnitDialogeState();
}

class _UnitDialogeState extends State<UnitDialoge> {
  String selectweight = '';
  String capacity = '';
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape:RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      title: Text('Unit'),
      content: Container(
        padding: EdgeInsets.symmetric(horizontal: 15),
        height: 75,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Weight',style: TextStyle(fontSize: 16),),
                Container(
                  height: 32,
                  decoration: BoxDecoration(
                      border: Border.all(color: Colors.black,width: 2)
                  ),
                  child: Row(
                    children: [
                      GestureDetector(
                        onTap:(){
                          setState(() {
                            selectweight = 'kg';
                          });
                        },
                        child: Container(
                          alignment: Alignment.center,
                          height: 30,
                          width: 50,
                          color: selectweight=='kg'?Colors.blue:Color(0xffE8EFFD),
                          child: Text('Kg'),
                        ),
                      ),
                      VerticalDivider(thickness: 2,width: 2,color: Colors.black,),

                      GestureDetector(
                        onTap: (){
                          setState(() {
                            selectweight = 'lbs';
                          });
                        },
                        child: Container(
                          alignment: Alignment.center,
                          height: 30,
                          width: 50,
                          color: selectweight=='lbs'?Colors.blue:Color(0xffE8EFFD),
                          child: Text('lbs'),
                        ),
                      ),
                    ],
                  ),
                )

              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Capacity',style: TextStyle(fontSize: 16),),
                Container(
                  height: 32,
                  decoration: BoxDecoration(
                      border: Border.all(color: Colors.black,width: 2)
                  ),
                  child: Row(
                    children: [
                      GestureDetector(
                        onTap:(){
                          setState(() {
                            capacity = 'ml';
                          });
                        },
                        child: Container(
                          alignment: Alignment.center,
                          height: 30,
                          width: 50,
                          color: capacity=='ml'?Colors.blue:Color(0xffE8EFFD),
                          child: Text('ml'),
                        ),
                      ),
                      VerticalDivider(thickness: 2,width: 2,color: Colors.black,),

                      GestureDetector(
                        onTap: (){
                          setState(() {
                            capacity = 'oz';
                          });
                        },
                        child: Container(
                          alignment: Alignment.center,
                          height: 30,
                          width: 50,
                          color: capacity=='oz'?Colors.blue:Color(0xffE8EFFD),
                          child: Text('oz'),
                        ),
                      ),
                    ],
                  ),
                )

              ],
            )
          ],
        ),
      ),
      actions: [
        TextButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: Text(
              'Cancle',
              style: TextStyle(
                  color: Colors.black, fontWeight: FontWeight.bold,fontSize: 18),
            )),
        TextButton(
            onPressed: () {},
            child: Text('OK',
                style: TextStyle(fontWeight: FontWeight.bold,fontSize: 18))),
      ],
    );
  }
}
