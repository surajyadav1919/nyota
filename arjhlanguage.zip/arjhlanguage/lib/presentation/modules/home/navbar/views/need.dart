import 'package:flutter/material.dart';

class Need extends StatefulWidget {
  const Need({Key? key}) : super(key: key);

  @override
  State<Need> createState() => _NeedState();
}

class _NeedState extends State<Need> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              Container(
                height: size.height * 0.4,
                // color: Colors.red,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Container(
                      height: size.height * 0.21,
                      width: size.width * 0.35,
                      child: Column(
                        children: [
                          Text(
                            '214 ml',
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 20),
                          ),
                          Image.asset('assets/images/waterdrops.png'),
                          Text(
                            'Tap to comfirm',
                            style: TextStyle(fontSize: 15),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Positioned(
                  left: 80,
                  bottom: 0,
                  child: Image.asset(
                    'assets/images/female.png',
                    scale: 1.6,
                  )),
            ],
          ),
          Container(
            // color: Colors.red,
            height: size.height * 0.10,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Text(
                  '0 / 2140 ml',
                  style: TextStyle(
                    fontSize: 30,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Image.asset('assets/images/waterdrops.png'),
              ],
            ),
          ),
          Text(
            "Today's Record",
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
          ),
          Container(
            // color: Colors.red,
            height: size.height * 0.22,
            child: ListView.builder(
                itemCount: 10,
                itemBuilder: (context, index) {
                  return Container(
                    height: size.height * 0.07,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Image.asset('assets/images/waterdrops.png'),
                        ),
                        Text('08:00 pm',style: TextStyle(fontSize: 16),),
                        Text('214 ml',style: TextStyle(fontSize: 16),),
                        IconButton(onPressed: (){},
                            icon: Icon(Icons.edit,color: Color(0xff1aa7dd),))
                      ],
                    ),
                  );
                }),
          )
        ],
      ),
    );
  }
}
