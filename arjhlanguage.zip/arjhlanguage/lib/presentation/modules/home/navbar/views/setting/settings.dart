import 'package:arjhlanguage/presentation/modules/home/navbar/views/setting/unit_dialoge.dart';
import 'package:flutter/material.dart';

class Settings extends StatefulWidget {
  const Settings({Key? key}) : super(key: key);

  @override
  State<Settings> createState() => _SettingsState();
}

class _SettingsState extends State<Settings> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'General',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          SizedBox(
            height: 10,
          ),
          CustomRow(
            title: 'Unit',
            txtbtn: 'lbs/ml',
            ontap: () {
              showDialog(context: context, builder: (BuildContext)=>UnitDialoge());
            },
          ),
          CustomRow(
            title: 'Intake Goal',
            txtbtn: '2140',
            ontap: () {
            },
          ),
          CustomRow(
            title: 'Language',
            txtbtn: 'Default',
            ontap: () {},
          ),
          SizedBox(
            height: 10,
          ),
          Text(
            'Personal Information',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          SizedBox(
            height: 10,
          ),
          CustomRow(
            title: 'Gender',
            txtbtn: 'Male',
            ontap: () {},
          ),
          CustomRow(
            title: 'Weight',
            txtbtn: '60kg',
            ontap: () {},
          ),
          CustomRow(
            title: 'Wake-up time',
            txtbtn: '8:00AM',
            ontap: () {},
          ),
          CustomRow(
            title: 'Bedtime',
            txtbtn: '10:00AM',
            ontap: () {},
          ),
          SizedBox(
            height: 10,
          ),
          Text(
            'System Information',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          SizedBox(
            height: 10,
          ),
          CustomRow(
            title: 'Schedule',
            txtbtn: '',
            ontap: () {},
          ),
          CustomRow(
            title: 'Sound',
            txtbtn: '',
            ontap: () {},
          ),
          CustomRow(
            title: 'Mode',
            txtbtn: '',
            ontap: () {},
          ),
        ],
      ),
    );
  }

}

class CustomRow extends StatelessWidget {
  const CustomRow(
      {Key? key,
      required this.title,
      required this.txtbtn,
      required this.ontap})
      : super(key: key);

  final String title;
  final String txtbtn;
  final VoidCallback ontap;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 36,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: TextStyle(fontSize: 18),
          ),
          TextButton(
              onPressed: ontap,
              child: Text(txtbtn, style: TextStyle(fontSize: 18)))
        ],
      ),
    );
  }
}
