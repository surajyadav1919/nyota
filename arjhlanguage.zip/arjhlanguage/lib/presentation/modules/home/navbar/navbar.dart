import 'package:arjhlanguage/constant/color_costants.dart';
import 'package:arjhlanguage/presentation/modules/home/navbar/views/need.dart';
import 'package:arjhlanguage/presentation/modules/home/navbar/views/setting/settings.dart';
import 'package:flutter/material.dart';

class Navbar extends StatefulWidget {
  const Navbar({Key? key}) : super(key: key);

  @override
  _NavbarState createState() => _NavbarState();
}

class _NavbarState extends State<Navbar> {
  int pageIndex = 1;

  final pages = [
    Center(child: Text(textAlign: TextAlign.center,'analytics\n under process',style: TextStyle(fontSize: 35,color: Colors.black),)),
    Need(),
    Settings(),
    Center(child: Text(textAlign: TextAlign.center,'tips\n under process',style: TextStyle(fontSize: 35,color: Colors.black),)),


  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorConstants.home,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        toolbarHeight: 80,
        elevation: 0,
        backgroundColor: ColorConstants.home,
        title: buildMyNavBar(context),
      ),
      body: pages[pageIndex],
    );
  }

  Container buildMyNavBar(BuildContext context) {
    return Container(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          GestureDetector(
            onTap: () {
              setState(() {
                pageIndex = 0;
              });
            },
            child: Container(
              height: 50,
              width: 50,
              child: pageIndex==0
                  ?Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(25),
                  ),
                  child: Image.asset('assets/images/6.png'))
                  :Image.asset('assets/images/6.png'),
            ),
          ),
          GestureDetector(
            onTap: () {
              setState(() {
                pageIndex = 1;
              });
            },
            child: Container(
              height: 50,
              width: 50,
              child: pageIndex==1
                  ?Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(25),
                  ),

                  child: Image.asset('assets/images/drop.png'))
                  :Image.asset('assets/images/drop.png'),
            ),

          ),
          GestureDetector(
            onTap: () {
              setState(() {
                pageIndex = 2;
              });
            },
            child: Container(
              height: 50,
              width: 50,
              child: pageIndex==2
                  ?Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(25),
                  ),

                  child: Image.asset('assets/images/setting.png'))
                  :Image.asset('assets/images/setting.png'),
            ),
          ),
          GestureDetector(
            onTap: () {
              setState(() {
                pageIndex = 3;
              });
            },
            child: Container(
              height: 60,
              width: 60,
              child: pageIndex==3
                  ?Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(30),
                  ),

                  child: Image.asset('assets/images/quicktips.png'))
                  :Image.asset('assets/images/quicktips.png'),
            ),
          ),
        ],
      ),
    );
  }
}


