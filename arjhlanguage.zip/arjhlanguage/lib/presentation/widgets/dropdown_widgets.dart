
import 'package:arjhlanguage/constant/color_costants.dart';
import 'package:flutter/material.dart';

class DropDown extends StatefulWidget {
  final String hint;
  final List<String> items;
  const DropDown({super.key, required this.hint, required this.items});
  @override
  State<StatefulWidget> createState() => _DropDownState();
}

class _DropDownState extends State<DropDown> {
  late List<String> items = widget.items; // Option 2
  String? _selecteditems; // Option 2

  @override
  Widget build(BuildContext context) {
    return DropdownButton(
      dropdownColor: ColorConstants.dropdowncolor,
      iconEnabledColor: Colors.white,
      iconSize: 30,
      style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 20),
      underline: SizedBox(),
      hint: Text(widget.hint,style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,),), // Not necessary for Option 1
      value: _selecteditems,
      onChanged: (newValue) {
        setState(() {
          _selecteditems = newValue;
        });
      },
      items: items.map((items) {
        return DropdownMenuItem(
          child: Text(items),
          value: items,
        );
      }).toList(),
    );
  }
}
