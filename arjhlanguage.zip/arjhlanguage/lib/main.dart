import 'package:arjhlanguage/service/localization_controler.dart';
import 'package:arjhlanguage/service/localization_services.dart';
import 'package:arjhlanguage/presentation/modules/splash/splash_screen.dart';
import 'package:arjhlanguage/test.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:get/utils.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  Get.put(LocalizationController());
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  MyApp({super.key});
 final LocalizationController localizationController = Get.find();
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      translations: MyTranslations(),
      debugShowCheckedModeBanner: false,
      locale: localizationController.locale,
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home:SplashScreen(),
      // home:WeightPicker(),


    );
  }
}
