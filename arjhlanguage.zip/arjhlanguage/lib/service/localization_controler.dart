import 'package:arjhlanguage/utils/sharedpreferenceutils.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';


class LocalizationController extends GetxController implements GetxService {
  LocalizationController() {
    loadCurrentLanguage();
  }

  Locale _locale = Locale(
    appLanguages[0].languageCode,
    appLanguages[0].countryCode,
  );
  static List<Locale> appLanguages = [
    const Locale("en", "US"),
    const Locale("hi", "IN"),
  ];

  List<Locale> _languages = [];

  Locale get locale => _locale;

  List<Locale> get languages => _languages;

  Future<void> setLanguage(Locale locale) async {
    await Get.updateLocale(locale);
    _locale = locale;

    await saveLanguage(_locale);
    // apiClient.updateHeader(
    //   sharedPreferences.getString(AppConstants.TOKEN),
    //   locale.languageCode,
    // );
    update();
  }

  Future<void> loadCurrentLanguage() async {
    String languageCode = await SharedPreferencesUtils.getString(
      key: "languageCode",
    );
    String countryCode = await SharedPreferencesUtils.getString(
      key: "countryCode",
    );
    _locale = Locale(
        languageCode.isEmpty
            ? appLanguages[0].languageCode
            : languageCode,
        countryCode.isEmpty
            ? appLanguages[0].languageCode
            : countryCode);

    for (int index = 0; index < appLanguages.length; index++) {
      if (appLanguages[index].languageCode == _locale.languageCode) {
        setSelectIndex(index);
        break;
      }
    }
    _languages = [];
    _languages.addAll(appLanguages);
    update();
  }

  Future<void> saveLanguage(Locale locale) async {
    SharedPreferencesUtils.saveSfString(
        key:"languageCode", value: locale.languageCode);
    SharedPreferencesUtils.saveSfString(
        key: "countryCode", value: locale.countryCode ?? "");
  }

  int _selectedIndex = 0;

  int get selectedIndex => _selectedIndex;

  void setSelectIndex(int index) {
    _selectedIndex = index;
    update();
  }
}