import 'package:get/get.dart';

class MyTranslations extends Translations {
  @override
  Map<String, Map<String, String>> get keys => {
        'en_US': {
          "agetitle":"To personlize your experience we need more details",
          "age":"Your Age",
          "gender":"What should we call you?",
          "weight":"Your Weight?",
          "height":"Your Height?",
          "wakeuptime":"Wake-Up-Time",
          "bedtime":"Bed Time",


        },
        'hi_IN': {
          "agetitle":"आपको बेहतर अनुभव प्रदान करने के लिए हमे कुछ और जानकारी चाहिए",
          "age":"आपकी उम्र",
          "gender":"what should we call you?",
          "weight":"your weight",
          "height":"your height",
          "wakeuptime":"wake-up-time",
          "bedtime":"bed time",

        }
      };
}
